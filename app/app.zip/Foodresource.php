<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Foodresource extends Model
{
    //
}
