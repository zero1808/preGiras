<?php
require('MultiCellBlt2.php');
//require('fpdf18/fpdf.php');

class PDF extends Multi {

    function Header() {
    	//indicamos la font a utilizar para el titulo
        $this->AddFont('Gotham-M','B','gotham-medium.php'); 
        //seteamos el titulo que aparecera en el navegador 
        $this->SetTitle(utf8_decode('Toma de Protesta Candidato PVEM'));

        //linea que simplemente me marca la mitad de la hoja como referencia
    	$this->Line(139.5,$this->getY(),140,250);

    	//bajamos la cabecera 13 espacios
        $this->Ln(10);
        //seteamos la fuente, el color de texto, y el color de fondo de el titulo
        $this->SetFont('Gotham-M','B',11);
        $this->SetTextColor(255,255,255);
        $this->SetFillColor(73, 168, 63);
        //escribimos titulo
        $this->Cell(0,5,utf8_decode('Toma de Protesta Candidato PVEM'),0,0,'C',1); //el completo es 279 bueno 280 /2 = 140  si seran 10 de cada borde, entonces 120



        $this->Ln();
    }
    function Contenido($imagenlogo) {
    	//seteamos el margen del contenido
    	$this->SetMargins(10, 10 ,151.5);
    	//mitad de la hoja de la mitad tomada para poner los datos del evento
    	$mitad=59;
    	//borde x para los numeros y los puntos
    	$bordex=10;
    	//variables locales
    	$fecha_evento="Domingo 2 de abril de 2017";
    	$hora_evento="11:00";

    	$domicilio_evento="Andador Cuatro Cienegas #32 Infonavit San Francisco";
   		$municipio_evento="Metepec";

   		$asistentes_aproximados="99,999";
   		$hora_convocatoria="11:00";
   		$duracion_evento="85";

   		$hora_termino_evento="12:00"; //sumar la duracion con la hora de inicio del evento
   		$vestimenta="Informal";
   		$responsable_politico="Cesar Gibran Cadena Espinosa";



    	//declaramos las fuentes a usar o tentativamente a usar ya que no sabemos cual es la original
	    $this->AddFont('Gotham-B','','gotham-book.php');
	    $this->AddFont('Gotham-B','B','gotham-book.php');
	    $this->AddFont('Gotham-M','','gotham-medium.php');
	    $this->AddFont('Helvetica','','helvetica.php');

    	//la imagen del PVEM
    	$this->Image($imagenlogo, $this->GetX()+10, $this->GetY()+15, 30,30);

    	//el primer espacio
    	$this->Ln(3);

    	//fecha y hora del evento
    	$this->SetFont('Helvetica', '', 9); //font de cuando se va a rellenar la informacion
		$this->SetTextColor(255,0,0); //color rojo para las letras
        $this->Cell(0, 5,utf8_decode($fecha_evento.", ".$hora_evento." hrs."), 0, 0, 'R', 0);

        //bajamos renglon
    	$this->Ln();

    	//domicilio y municipio del evento
    	$this->SetFont('Helvetica', '', 9); //font de cuando se va a rellenar la informacion
		$this->SetTextColor(0,0,0); //color negro para las letras
		//posicionamos ala mitad de la hoja
		$this->setX($mitad);
        $this->MultiCell(0, 5,utf8_decode($domicilio_evento.", ".$municipio_evento."."), 0, 'R', 0);

        $this->setY($this->GetY()+2);
       

    	//asistentes del evento
    	$this->SetFont('Helvetica', '', 9); //font de cuando se va a rellenar la informacion
		$this->SetTextColor(118,118,118); //color gris para las letras
		//posicionamos ala mitad de la hoja
		$this->setX($mitad);
        $this->Cell(55, 5,utf8_decode("Asistentes: "), 0, 0, 'R', 0);

        //respuesta
        $this->SetFont('Helvetica', '', 9); //font de cuando se va a rellenar la informacion
		$this->SetTextColor(0,0,0); //color gris para las letras
        $this->Cell(0, 5,utf8_decode($asistentes_aproximados), 0, 0, 'R', 0);


        //bajamos renglon
    	$this->Ln(7);

         //asistentes del evento
    	$this->SetFont('Helvetica', '', 9); //font de cuando se va a rellenar la informacion
		$this->SetTextColor(118,118,118); //color gris para las letras
		//posicionamos ala mitad de la hoja
		$this->setX($mitad);
        $this->Cell(55, 5,utf8_decode("Hora de convocatoria: "), 0, 0, 'R', 0);

        //respuesta
        $this->SetFont('Helvetica', '', 9); //font de cuando se va a rellenar la informacion
		$this->SetTextColor(0,0,0); //color gris para las letras
        $this->Cell(0, 5,utf8_decode($hora_convocatoria), 0, 0, 'R', 0);


         //bajamos renglon
    	$this->Ln(7);

         //asistentes del evento
    	$this->SetFont('Helvetica', '', 9); //font de cuando se va a rellenar la informacion
		$this->SetTextColor(118,118,118); //color gris para las letras
		//posicionamos ala mitad de la hoja
		$this->setX($mitad);
        $this->Cell(50, 5,utf8_decode("Duracion: "), 0, 0, 'R', 0);

        //respuesta
        $this->SetFont('Helvetica', '', 9); //font de cuando se va a rellenar la informacion
		$this->SetTextColor(0,0,0); //color gris para las letras
        $this->Cell(0, 5,utf8_decode($duracion_evento." Minutos"), 0, 0, 'R', 0);


         //bajamos renglon
    	$this->Ln(7);

         //asistentes del evento
    	$this->SetFont('Helvetica', '', 9); //font de cuando se va a rellenar la informacion
		$this->SetTextColor(118,118,118); //color gris para las letras
		//posicionamos ala mitad de la hoja
		$this->setX($mitad);
        $this->Cell(50, 5,utf8_decode("Término del Evento: "), 0, 0, 'R', 0);

        //respuesta
        $this->SetFont('Helvetica', '', 9); //font de cuando se va a rellenar la informacion
		$this->SetTextColor(0,0,0); //color gris para las letras
        $this->Cell(0, 5,utf8_decode($hora_termino_evento." hrs."), 0, 0, 'R', 0);

         //bajamos renglon
    	$this->Ln(7);

         //asistentes del evento
    	$this->SetFont('Helvetica', '', 9); //font de cuando se va a rellenar la informacion
		$this->SetTextColor(118,118,118); //color gris para las letras
		//posicionamos ala mitad de la hoja
		$this->setX($mitad);
        $this->Cell(50, 5,utf8_decode("Vestimenta: "), 0, 0, 'R', 0);

        //respuesta
        $this->SetFont('Helvetica', '', 9); //font de cuando se va a rellenar la informacion
		$this->SetTextColor(0,0,0); //color gris para las letras
        $this->Cell(0, 5,utf8_decode($vestimenta), 0, 0, 'R', 0);


        //bajamos renglon
    	$this->Ln(7);

         //asistentes del evento
    	$this->SetFont('Helvetica', '', 9); //font de cuando se va a rellenar la informacion
		$this->SetTextColor(118,118,118); //color gris para las letras
		//posicionamos ala mitad de la hoja
		$this->setX(25);
        $this->Cell(50, 5,utf8_decode("Responsable del Evento: "), 0, 0, 'R', 0);

        //respuesta
        $this->SetFont('Helvetica', '', 9); //font de cuando se va a rellenar la informacion
		$this->SetTextColor(0,0,0); //color gris para las letras
        $this->MultiCell(0, 5,utf8_decode($responsable_politico), 0, 'R', 0);


        $this->Ln(1);

         $this->SetFillColor(231, 234,243); //color de fondo donde se va a rellenar los campos (como azul claro)
        $this->SetFont('Helvetica', '', 9); //font de cuando se va a rellenar la informacion
		$this->SetTextColor(0,0,0); //color gris para las letras
        $this->Cell(25, 5,utf8_decode("Programa:"), 0,0, 'C', 1);

        $this->Ln();
         $this->Ln();

      
        $sample_text = 'This is bulleted text. The text is indented and the bullet appears at the first line only. This list is built with a single call to MultiCellBltArray().';
        //aqui vienen los numeros
        //Test 3
		$test3 = array();
		$test3['bullet'] = 1;
		$test3['margin'] = ')     ';
		$test3['indent'] = 10;
		$test3['spacer'] = 2.5; //espacio
		$test3['text'] = array();
		for ($i=0; $i<4; $i++)
		{
		    $test3['text'][$i] = $sample_text;
		}
		$this->SetX($bordeX);
		$this->MultiCellBltArray(120,6,$test3);



		$this->Ln();

        $this->SetFillColor(231, 234,243); //color de fondo donde se va a rellenar los campos (como azul claro)
        $this->SetFont('Helvetica', '', 9); //font de cuando se va a rellenar la informacion
		$this->SetTextColor(0,0,0); //color gris para las letras
        $this->Cell(25, 5,utf8_decode("Asistentes:"), 0,0, 'C', 1);

        $this->Ln();
        $this->Ln();

      
	
		$sample_text = 'This is bulleted text. The text is indented and the bullet appears at the first line';

		//Test1
		$test1 = array();
		$test1['bullet'] = chr(149);
		$test1['margin'] = ' ';
		$test1['indent'] = 10;
		$test1['spacer'] = 0;
		$test1['text'] = array();
		for ($i=0; $i<9; $i++)
		{
		    $test1['text'][$i] = $sample_text;
		}
		$this->SetX($bordeX);
		$this->MultiCellBltArray(120,6,$test1);

    }
}

$pdf=new PDF('L','mm','Letter');
$pdf->SetMargins(10, 10 ,149.5);
$pdf->SetAutoPageBreak(false);
$pdf->AddPage();

$imagenlogo='https://upload.wikimedia.org/wikipedia/commons/thumb/3/31/Mexican_Green_Party.svg/160px-Mexican_Green_Party.svg.png';
$pdf->Contenido($imagenlogo);

$pdf->Ln();
$pdf->Output();
?>